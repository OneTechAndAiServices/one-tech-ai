import Products from '@/components/admin/products/Products'
import React from 'react'

const page = () => {
  return (
    <Products/>
  )
}

export default page