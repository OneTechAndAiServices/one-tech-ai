
import Blog from '@/components/admin/blogs/Blogs'
import React from 'react'

function page() {
  return (
    <div><Blog /></div>
  )
}

export default page