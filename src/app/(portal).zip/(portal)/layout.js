"use client"


import Sidebar from "@/components/admin/sidebar/Sidebar";
import { Box } from "@mui/material";


export default function WebsiteLayout({ children }) {
  return (

  <>
<Box display={"flex"}>
  <Box width={["0%" , "0%" , "18%"]} bgcolor={"#3889FF"} height={"100vh"}>
    <Sidebar/>
  </Box>
  <Box width={["100%" , "100%" , "82%"]}>
        {children}
  </Box>
</Box>
  </>
   
  );
}