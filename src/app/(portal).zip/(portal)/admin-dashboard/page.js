import React from 'react'

function page() {
  return (
    <div>Admin dashboard</div>
  )
}

export default page
