import Services from '@/components/admin/services/Services'
import React from 'react'

const page = () => {
  return (
    <div><Services/></div>
  )
}

export default page